import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import 'bottom_nav_bar.dart';

class MainScaffold extends StatefulWidget {
  final Widget child;
  final int currentIndex;

  const MainScaffold({
    super.key,
    required this.child,
    required this.currentIndex,
  });

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> {
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.currentIndex;
  }

  void _onTabTapped(int index) {
    if (_currentIndex == index) return;

    // Update the current index
    setState(() {
      _currentIndex = index;
    });

    // Navigate to the selected screen
    String routeName;
    switch (index) {
      case 0:
        routeName = '/home';
        break;
      case 1:
        routeName = '/conversion';
        break;
      case 2:
        routeName = '/history';
        break;
      case 3:
        routeName = '/alerts';
        break;
      case 4:
        routeName = '/settings';
        break;
      default:
        return;
    }
    
    // Use pushReplacementNamed to avoid building up a stack
    Navigator.pushReplacementNamed(context, routeName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widget.child,
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
      ),
    );
  }
}